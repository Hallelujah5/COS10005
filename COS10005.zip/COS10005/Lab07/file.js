


function displayFibo() {
    
    var n = document.getElementById("num").value;
    var output = document.getElementById("output");
    var fibArray = [1, 1]; // Initialize array with first two Fibonacci numbers
    if (n < 0) {
        output.innerHTML = "Please enter a valid number.";
    }
    else {
    
    // Calculate subsequent Fibonacci numbers
    for (var i = 2; i < n; i++) {
        fibArray.push(fibArray[i - 1] + fibArray[i - 2]);
    }
    
    output.innerHTML = "The sequences are: "
    for (var i = 0; i < fibArray.length; i++) {
            
        output.innerHTML += fibArray[i] + " ";
    }
}
}

