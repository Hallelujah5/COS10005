'use strict';

/* write functions that define the action for each event */
function showTip () {
	let sidTip = document.getElementById("sidTip"); 		//obtain access to the HTML tool tip element using id "sidTip" and link it a varialbe named sidTip
	
	sidTip.style.display = "inline";  	//display the HTML tool tip element sidTip bying change the value of its CSS property "display" to "inline"
}

function hideTip () {  														//this function hides the tool tip
	
	let sidTip = document.getElementById("sidTip");			//first, get access to the tool tip HTML element
						
				
	sidTip.style.display = "none"; 					//then, hide the tool tip HTML element by changing its CSS property "display" to "none"
}

function init () {							/* the init function links functions to appropriate events of corresponding HTML elements */
	
	let sid = document.getElementById("sid");								/* create a variable named sid get access to the HTML element by its id "sid" and link it to sid */	
	let pid = document.getElementById("pwd1");
	pid.addEventListener("mouseover", show_pwdTip);
	pid.addEventListener("mouseout", hide_pwdTip);
	pid.addEventListener("focus",show_pwdTip);
	pid.addEventListener("blur",hide_pwdTip);

	sid.addEventListener("mouseover", showTip);
	sid.addEventListener("focus",showTip);
	sid.addEventListener("mouseout", hideTip);													/* link function hideTip to the onmouseout event of sid  */
	sid.addEventListener("blur",hideTip);
}


function show_pwdTip() {
	let pid = document.getElementById("pwdTip");
	pid.style.display="inline";	
}

function hide_pwdTip(){
	let pid = document.getElementById("pwdTip");
	pid.style.display = "none";
}






window.onload = init();												/* link function init to the onload event of the window so that function init will be called when the page is loaded */









