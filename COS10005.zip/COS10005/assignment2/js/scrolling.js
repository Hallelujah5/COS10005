/*filename: scrolling.js
author: Hallelujah
created: 3/15/2024
last modified: 3/15/2024
description: implementing the scrolling horizontally function in the main page in index.html of the svg arrows
*/ 


function Scrolling() {
    const $container = $('#div-scroll');
    const $leftArrow = $('#arrow-left');
    const $rightArrow = $('#arrow-right');
    const scrollAmount = 100; 
    const animationDuration = 500; //ms

    $leftArrow.on('click', function() {
        $container.animate({scrollLeft: 0}, animationDuration);
    });

    $rightArrow.on('click', function() {
        $container.animate({scrollLeft: $container[0].scrollWidth}, animationDuration);
    });
}




$(document).ready(Scrolling);