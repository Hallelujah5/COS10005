
// Show/hide delivery address textarea based on delivery option selection
function deliAddress() {
    function showHideDeli() {
        if ($(this).val() === 'delivery') {             //I used 'this' to target the current DOM element that triggers the event.
            $('#delivery-ad-section').show();
        } else {
            $('#delivery-ad-section').hide();
        }
    }
    // Show/hide credit card information fields based on payment option selection
    function showHideCred() {
        if ($(this).val() === 'online') {
            $('#creditCardInfo').show();
        } else {
            $('#creditCardInfo').hide();
        }
    }

    // Dynamically update maximum length of credit card number field based on selected credit card type
    function credLength() {
        var maxLength = ($(this).val() === 'amex') ? 15 : 16;           //if american express then 15, else 16 for the other two.
        $('#creditCardNumber').attr('maxlength', maxLength);
    }

    $('#deliveryOption').change(showHideDeli);
    $('#paymentOption').change(showHideCred);
    $('#creditCardType').change(credLength);

}
$(document).ready(deliAddress);


function billAddress() {
    // Function to fill billing with delivery address
    function fillBilling() {
        var deliveryAddress = $('#delivery-ad').val();
        if (deliveryAddress.trim() === '') {
            alert('Please enter your delivery address first.');
            $('#sameAsDelivery').prop('checked', false);        //unchecks tick
        } else {
            $('#billing-address').val(deliveryAddress);
        }
    }


    
    // Check/uncheck sameAsDelivery checkbox based on delivery option selection
    $('#deliveryOption').change(function() {
        if ($(this).val() === 'delivery') {
            $('#delivery-ad-section').show();
        } else {
            $('#delivery-ad-section').hide();
            $('#sameAsDelivery').prop('checked', false);                //unchecks the tick
            $('#billing-address').val('');                         //clears the bill address (since it's pickup the user might want to redecide their pick-up location)
        }
    });
    



    // Fill billing address when sameAsDelivery checkbox is checked
    $('#sameAsDelivery').change(function() {
        if ($(this).prop('checked')) {
            fillBilling();
        }
    });
    
    // Function to handle changes in the delivery address input
    $('#delivery-ad').change(function() {
        if ($('#sameAsDelivery').prop('checked')) {              //so when user updates the delivery address, and the checkbox is still ticked, it automatically updates.
            fillBilling();
        }
    });
}
$(document).ready(billAddress);


//This function outputs the corresponding cards based on the users choice (if pay online is chosen)
function cardImages() {
    $('#creditCardType').change(function() {
        var selectedCard = $(this).val();
        var cardImage = '';
        switch(selectedCard) {
            case 'visa':
                cardImage = '<img src="images/svg/VisaPaymentCard.svg" alt="Visa" class="credit-card-image">';      //inserts Visa image
                break;
            case 'mastercard':
                cardImage = '<img src="images/svg/MasterCard.svg" alt="MasterCard" class="credit-card-image">';     //inserts Mastercard image
                break;
            case 'amex':
                cardImage = '<img src="images/svg/AmericanExpressCard.svg" alt="American Express" class="credit-card-image">';      //inserts Amex card.
                break;
            default:
                cardImage = '';     //otherwise none
                break;
        }
        $('#creditCardImage').html(cardImage);
    });
}
$(document).ready(cardImages);






function validate() {
    var error = "";
    var result = true;
    // Check postcode format
    var postcode = $('#postcode').val();
    if (postcode.length < 4 || !/^\d+$/.test(postcode)) {
        error += "Please enter a valid postcode.\n";
    }

    //check contact number if it's valid
    var contact = $('#contact-number').val();
    if (!/^\d+$/.test(contact)) {
        error += "Please enter the correct format of the contact number. \n";
    }

    // Show error message if any
    if (error != "") {
        alert(error);
        result = false;
    }
    return result;
}
function init(){
    $("#order-form").submit(validate);
}

$(document).ready(init);