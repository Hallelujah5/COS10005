/*filename: validation.js
author: Hallelujah
created: 3/15/2024
last modified: 3/15/2024
description: validation file for register.html
*/ 



function validate() {
	var uname = $("#username").val();
	var pwd = $("#password").val();
	var email = $("#email").val();
	var male = $("#male").prop("checked");
	var female = $("#female").prop("checked");
    var agree = $("#agree").prop("checked");
    var fav_ice = $("#fav-ice-cream").val();




var errMsg = "";
var result = true;


if (uname == "") {
    errMsg += "Username cannot be blank.\n";
}
if (pwd == "") {
    errMsg += "Password cannot be blank.\n";
}
if (email == "") {
    errMsg += "Email cannot be blank.\n";
}
if ((!male)&&(!female)) {
    errMsg += "A gender must be selected.\n";
}
if (fav_ice == "") {
    errMsg +="Please choose your favorite ice cream.\n";
}
if (pwd.length < 9){
    errMsg += "Password must be at least 9-character long.\n";
}
if (!agree) {
    errMsg += "Please agree to the Terms and Conditions.\n";
}

if (errMsg != ""){
    alert(errMsg);
    result = false;
}
return result;
}

function init() {
	$("#regform").submit(validate);
}

$(document).ready(init);