/*filename: faqs.js
author: Hallelujah
created: 3/15/2024
last modified: 3/15/2024
description: main Js script for every html page
*/ 



function displayTooltip() {                                  //delayed message tooltip pop up
    $('#unavailable-link').mouseenter(function() {
        setTimeout(function() {
            $('#tooltip').show();
        }, 250); // 250ms
    });

    $('#unavailable-link').mouseleave(function() {
        $('#tooltip').hide();
    });
}
function activeUnderline() {
    var currentPage = location.pathname.split("/").pop(); // Get current page filename
    $("nav ul li a").each(function() {
      if ($(this).attr("href") === currentPage) {
        $(this).addClass("active");
      }
    });
}

let cartCount = 0;
let totalPrice = 0;


//This function calculates your total prices and items in your shopping cart based on the Featured Items in index.html
//You can add-to-cart each items and it will automatically updates in your cart.
function addToCart(itemName, itemPrice) {
  cartCount++;
  totalPrice += itemPrice;
  updateCartCount(cartCount);
  updateTotalPrice(totalPrice);
  alert('Added to cart: ' + itemName);
}

function updateCartCount(count) {
  document.getElementById('cart-count').textContent = count;
}
function updateTotalPrice(price) {
    document.getElementById('total-price').textContent = price.toFixed(2);
  }


$(document).ready(activeUnderline);
$(document).ready(displayTooltip);
